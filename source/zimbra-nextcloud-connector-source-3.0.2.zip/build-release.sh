#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
version="3.0.2"
dist_dir="$project_dir/dist"
release_name="zimbra-nextcloud-connector-${version}"
release_dir="$dist_dir/$release_name"
stage_dir="$(mktemp -d "$project_dir/.release-stage.XXXXXX")"

cleanup() {
  if [[ -d "$stage_dir" ]]; then
    find "$stage_dir" -depth -mindepth 1 -delete
    rmdir "$stage_dir"
  fi
}
trap cleanup EXIT

cd "$project_dir"
for generated_dir in "$project_dir/build" "$project_dir/pkg"; do
  if [[ -d "$generated_dir" ]]; then
    find "$generated_dir" -depth -mindepth 1 -delete
    rmdir "$generated_dir"
  fi
done
npm run build
npm run package
bash ./test-frontend-build.sh
bash ./test-installer.sh
./server/test-local.sh

mkdir -p "$stage_dir/$release_name/frontend" "$stage_dir/$release_name/server" "$stage_dir/$release_name/source"
install -m 0755 installer/configure.sh "$stage_dir/$release_name/configure.sh"
install -m 0755 installer/install.sh "$stage_dir/$release_name/install.sh"
install -m 0755 installer/repair-modern-ui.sh "$stage_dir/$release_name/repair-modern-ui.sh"
install -m 0755 installer/uninstall.sh "$stage_dir/$release_name/uninstall.sh"
install -m 0755 installer/storage-report.sh "$stage_dir/$release_name/storage-report.sh"
install -m 0755 installer/diagnose.sh "$stage_dir/$release_name/diagnose.sh"
install -m 0755 installer/lifecycle-report.sh "$stage_dir/$release_name/lifecycle-report.sh"
install -m 0644 installer/i18n.sh "$stage_dir/$release_name/i18n.sh"
install -m 0644 README.md "$stage_dir/$release_name/README.md"
install -m 0644 README_FR.md "$stage_dir/$release_name/README_FR.md"
install -m 0644 CONTRIBUTING.md "$stage_dir/$release_name/CONTRIBUTING.md"
install -m 0644 SECURITY.md "$stage_dir/$release_name/SECURITY.md"
install -m 0644 CHANGELOG.md "$stage_dir/$release_name/CHANGELOG.md"
install -m 0644 LICENSE "$stage_dir/$release_name/LICENSE"
install -m 0644 pkg/com_nextcloud_connector.zip "$stage_dir/$release_name/frontend/com_nextcloud_connector.zip"
install -m 0644 server/build/com_nextcloud_connector.jar "$stage_dir/$release_name/server/com_nextcloud_connector.jar"
install -m 0600 server/resources/config.example.properties "$stage_dir/$release_name/server/config.example.properties"
mkdir -p "$stage_dir/$release_name/server/source-build"
cp -R server/src server/resources server/META-INF "$stage_dir/$release_name/server/source-build/"
install -m 0755 server/build-on-zimbra.sh "$stage_dir/$release_name/server/source-build/build-on-zimbra.sh"

source_zip="$stage_dir/$release_name/source/zimbra-nextcloud-connector-source-${version}.zip"
zip -q -r "$source_zip" . \
  -x 'node_modules/*' 'build/*' 'pkg/*' 'dist/*' 'server/build/*' \
     'server/.zimbra-build-test.*/*' '.release-stage.*/*' '.git/*'
(cd "$stage_dir/$release_name" && sha256sum \
  frontend/com_nextcloud_connector.zip \
  server/com_nextcloud_connector.jar \
  source/zimbra-nextcloud-connector-source-${version}.zip > SHA256SUMS)

mkdir -p "$dist_dir"
if [[ -d "$release_dir" ]]; then
  find "$release_dir" -depth -mindepth 1 -delete
  rmdir "$release_dir"
fi
mv "$stage_dir/$release_name" "$release_dir"

bundle="$dist_dir/zimbra-nextcloud-connector-v${version}.zip"
if [[ -f "$bundle" ]]; then
  find "$bundle" -maxdepth 0 -type f -delete
fi
checksum="$bundle.sha256"
if [[ -f "$checksum" ]]; then
  find "$checksum" -maxdepth 0 -type f -delete
fi
(cd "$dist_dir" && zip -q -r "$(basename "$bundle")" "$release_name")
(cd "$dist_dir" && sha256sum "$(basename "$bundle")" > "$(basename "$checksum")")

echo "$bundle"
echo "$checksum"
